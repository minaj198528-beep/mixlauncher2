package com.mixlauncher

import android.content.Context
import android.content.Intent
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap
import androidx.core.view.WindowCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        setContent { LauncherApp() }
    }
}

enum class LStyle(val label: String, val note: String) {
    GLASS("Glass", "iOS Liquid Glass + Samsung smooth"),
    DOT("Dot", "Nothing OS minimal dot style"),
    COLOR("Color", "ColorOS / OriginOS soft colours")
}

class Look(
    val surface: Brush, val border: Color, val text: Color,
    val radius: Dp, val font: FontFamily, val drawerBg: Color, val iconRadius: Dp, val mono: Boolean
)

fun lookFor(s: LStyle): Look = when (s) {
    LStyle.GLASS -> Look(
        Brush.verticalGradient(listOf(Color.White.copy(0.32f), Color.White.copy(0.12f))),
        Color.White.copy(0.5f), Color.White, 30.dp, FontFamily.SansSerif,
        Color.Black.copy(0.5f), 16.dp, false
    )
    LStyle.DOT -> Look(
        SolidColor(Color.Black.copy(0.75f)), Color(0xFFD71920), Color.White,
        12.dp, FontFamily.Monospace, Color.Black.copy(0.92f), 14.dp, true
    )
    LStyle.COLOR -> Look(
        SolidColor(Color(0xFFFFF1E6).copy(0.93f)), Color(0xFFFFB26B), Color(0xFF3A2A1E),
        38.dp, FontFamily.SansSerif, Color(0xFFFFF8F2).copy(0.96f), 22.dp, false
    )
}

fun Modifier.panel(l: Look): Modifier {
    val shape = RoundedCornerShape(l.radius)
    return this.clip(shape).background(l.surface, shape).border(1.dp, l.border, shape)
}

class AppItem(val label: String, val pkg: String, val icon: ImageBitmap)

fun loadApps(ctx: Context): List<AppItem> {
    val pm = ctx.packageManager
    val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
    return pm.queryIntentActivities(intent, 0)
        .map { AppItem(it.loadLabel(pm).toString(), it.activityInfo.packageName, it.loadIcon(pm).toBitmap(128, 128).asImageBitmap()) }
        .filter { it.pkg != ctx.packageName }
        .distinctBy { it.pkg }
        .sortedBy { it.label.lowercase() }
}

fun launch(ctx: Context, pkg: String) {
    ctx.packageManager.getLaunchIntentForPackage(pkg)?.let {
        it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(it)
    }
}

@Composable
fun rememberTilt(): State<Offset> {
    val ctx = LocalContext.current
    val tilt = remember { mutableStateOf(Offset.Zero) }
    DisposableEffect(Unit) {
        val sm = ctx.getSystemService(Context.SENSOR_SERVICE) as SensorManager
        val sensor = sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
        val l = object : SensorEventListener {
            override fun onSensorChanged(e: SensorEvent) {
                val nx = (-e.values[0]).coerceIn(-5f, 5f)
                val ny = (e.values[1] - 5f).coerceIn(-5f, 5f)
                val o = tilt.value
                tilt.value = Offset(o.x * 0.92f + nx * 0.08f, o.y * 0.92f + ny * 0.08f)
            }
            override fun onAccuracyChanged(s: Sensor?, a: Int) {}
        }
        if (sensor != null) sm.registerListener(l, sensor, SensorManager.SENSOR_DELAY_UI)
        onDispose { sm.unregisterListener(l) }
    }
    return tilt
}

@Composable
fun LauncherApp() {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("mix", Context.MODE_PRIVATE) }
    var style by remember { mutableStateOf(runCatching { LStyle.valueOf(prefs.getString("style", "GLASS")!!) }.getOrDefault(LStyle.GLASS)) }
    var dock by remember { mutableStateOf(prefs.getString("dock", "")!!.split(",").filter { it.isNotEmpty() }) }
    var reload by remember { mutableIntStateOf(0) }
    var drawerOpen by remember { mutableStateOf(false) }
    var showStyles by remember { mutableStateOf(false) }

    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val obs = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_RESUME) reload++ }
        owner.lifecycle.addObserver(obs)
        onDispose { owner.lifecycle.removeObserver(obs) }
    }
    val apps by produceState(emptyList<AppItem>(), reload) {
        value = withContext(Dispatchers.IO) { loadApps(ctx) }
    }

    val look = lookFor(style)
    val tilt = rememberTilt()
    val p by animateFloatAsState(
        if (drawerOpen) 1f else 0f,
        spring(dampingRatio = 0.85f, stiffness = Spring.StiffnessMediumLow), label = "drawer"
    )
    BackHandler(drawerOpen) { drawerOpen = false }

    fun toggleDock(pkg: String) {
        val cur = if (dock.isEmpty()) apps.take(4).map { it.pkg } else dock
        dock = if (pkg in cur) cur - pkg else (cur + pkg).takeLast(5)
        prefs.edit().putString("dock", dock.joinToString(",")).apply()
    }
    val dockApps = if (dock.isEmpty()) apps.take(4) else dock.mapNotNull { d -> apps.find { it.pkg == d } }
    val dockPkgs = dockApps.map { it.pkg }

    Box(
        Modifier
            .fillMaxSize()
            .pointerInput(Unit) {
                var acc = 0f
                detectVerticalDragGestures(
                    onDragStart = { acc = 0f },
                    onDragEnd = { if (acc < -80f) drawerOpen = true },
                    onVerticalDrag = { _, d -> acc += d }
                )
            }
            .pointerInput(Unit) { detectTapGestures(onLongPress = { showStyles = true }) }
    ) {
        // Home
        Box(
            Modifier
                .fillMaxSize()
                .graphicsLayer { alpha = 1f - 0.7f * p; scaleX = 1f - 0.06f * p; scaleY = 1f - 0.06f * p }
        ) {
            ClockBlock(style, look, tilt, Modifier.align(Alignment.TopStart).statusBarsPadding().padding(start = 28.dp, top = 56.dp))
            Row(
                Modifier
                    .align(Alignment.BottomCenter)
                    .navigationBarsPadding()
                    .padding(horizontal = 20.dp, vertical = 16.dp)
                    .graphicsLayer { translationX = tilt.value.x * 1.5f }
                    .fillMaxWidth()
                    .panel(look)
                    .padding(vertical = 14.dp),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                dockApps.forEach { a ->
                    AppIcon(a, look, style, false, true, { launch(ctx, a.pkg) }, { toggleDock(a.pkg) })
                }
            }
            Text(
                "swipe up", color = Color.White.copy(0.6f), fontSize = 11.sp, fontFamily = look.font,
                modifier = Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(bottom = 2.dp)
            )
        }
        // Drawer
        if (p > 0.01f) {
            Drawer(
                apps, look, style, dockPkgs, ctx,
                onToggleDock = { toggleDock(it) },
                onClose = { drawerOpen = false },
                modifier = Modifier.graphicsLayer { alpha = p; translationY = (1f - p) * size.height }
            )
        }
    }

    if (showStyles) {
        AlertDialog(
            onDismissRequest = { showStyles = false },
            confirmButton = {},
            title = { Text("Choose style") },
            text = {
                Column {
                    LStyle.values().forEach { s ->
                        TextButton(onClick = {
                            style = s; prefs.edit().putString("style", s.name).apply(); showStyles = false
                        }) { Text("${s.label}  -  ${s.note}") }
                    }
                }
            }
        )
    }
}

@Composable
fun ClockBlock(style: LStyle, look: Look, tilt: State<Offset>, modifier: Modifier) {
    var now by remember { mutableStateOf(LocalDateTime.now()) }
    LaunchedEffect(Unit) { while (true) { now = LocalDateTime.now(); delay(1000) } }
    val shadow = Shadow(Color.Black.copy(0.4f), Offset(0f, 4f), 14f)
    Column(modifier.graphicsLayer { translationX = tilt.value.x * 3f; translationY = tilt.value.y * 2f }) {
        Text(
            now.format(DateTimeFormatter.ofPattern("HH:mm")),
            style = TextStyle(
                color = Color.White, fontSize = if (style == LStyle.DOT) 64.sp else 84.sp,
                fontWeight = when (style) { LStyle.GLASS -> FontWeight.Light; LStyle.DOT -> FontWeight.Bold; LStyle.COLOR -> FontWeight.SemiBold },
                fontFamily = look.font, shadow = shadow
            )
        )
        Text(
            now.format(DateTimeFormatter.ofPattern("EEE, d MMM")).let { if (style == LStyle.DOT) it.uppercase() else it },
            style = TextStyle(color = if (style == LStyle.DOT) Color(0xFFD71920) else Color.White.copy(0.9f), fontSize = 16.sp, fontFamily = look.font, shadow = shadow)
        )
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun AppIcon(
    app: AppItem, look: Look, style: LStyle, showLabel: Boolean, docked: Boolean,
    onLaunch: () -> Unit, onToggleDock: () -> Unit
) {
    val ctx = LocalContext.current
    var menu by remember { mutableStateOf(false) }
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val scale by animateFloatAsState(
        if (pressed) 0.82f else 1f,
        spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessMedium), label = "press"
    )
    Box {
        Column(
            Modifier
                .graphicsLayer { scaleX = scale; scaleY = scale }
                .combinedClickable(interactionSource = src, indication = null, onClick = onLaunch, onLongClick = { menu = true })
                .padding(6.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Image(
                app.icon, app.label,
                Modifier.size(56.dp).clip(RoundedCornerShape(look.iconRadius)),
                colorFilter = if (style == LStyle.DOT) ColorFilter.colorMatrix(ColorMatrix().apply { setToSaturation(0f) }) else null
            )
            if (showLabel) {
                Text(
                    app.label, color = look.text, fontSize = 11.sp, fontFamily = look.font,
                    maxLines = 1, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center,
                    modifier = Modifier.padding(top = 4.dp).width(68.dp)
                )
            }
        }
        DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
            DropdownMenuItem(text = { Text(if (docked) "Remove from dock" else "Add to dock") }, onClick = { menu = false; onToggleDock() })
            DropdownMenuItem(text = { Text("App info") }, onClick = {
                menu = false
                ctx.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${app.pkg}")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            })
            DropdownMenuItem(text = { Text("Uninstall") }, onClick = {
                menu = false
                ctx.startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:${app.pkg}")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            })
        }
    }
}

@Composable
fun Drawer(
    apps: List<AppItem>, look: Look, style: LStyle, dockPkgs: List<String>, ctx: Context,
    onToggleDock: (String) -> Unit, onClose: () -> Unit, modifier: Modifier
) {
    var q by remember { mutableStateOf("") }
    val list = apps.filter { it.label.contains(q, ignoreCase = true) }
    Column(modifier.fillMaxSize().background(look.drawerBg).statusBarsPadding().padding(horizontal = 16.dp)) {
        Box(
            Modifier.align(Alignment.CenterHorizontally).padding(vertical = 10.dp)
                .size(width = 44.dp, height = 5.dp).clip(RoundedCornerShape(3.dp))
                .background(look.text.copy(0.4f)).pointerInput(Unit) { detectTapGestures { onClose() } }
        )
        TextField(
            value = q, onValueChange = { q = it },
            placeholder = { Text("Search apps", color = look.text.copy(0.6f), fontFamily = look.font) },
            singleLine = true,
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
            keyboardActions = KeyboardActions(onSearch = { list.firstOrNull()?.let { launch(ctx, it.pkg) } }),
            modifier = Modifier.fillMaxWidth().panel(look),
            colors = TextFieldDefaults.colors(
                focusedContainerColor = Color.Transparent, unfocusedContainerColor = Color.Transparent,
                focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent,
                focusedTextColor = look.text, unfocusedTextColor = look.text, cursorColor = look.text
            )
        )
        Spacer(Modifier.height(12.dp))
        LazyVerticalGrid(GridCells.Fixed(4), contentPadding = PaddingValues(bottom = 56.dp)) {
            items(list, key = { it.pkg }) { a ->
                AppIcon(a, look, style, true, a.pkg in dockPkgs, { launch(ctx, a.pkg) }, { onToggleDock(a.pkg) })
            }
        }
    }
}
